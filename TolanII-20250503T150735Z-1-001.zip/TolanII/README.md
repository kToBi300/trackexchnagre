# TrackExchange - Secure Currency Exchange Platform

TrackExchange is a modern web application for secure currency exchange and money transfers. Built with Django and Tailwind CSS, it provides a beautiful and intuitive user interface for managing multiple currency wallets and performing transactions.

## Features

- Multi-currency wallet management
- Real-time currency conversion
- Secure bank transfers
- Transaction history
- User authentication with PIN
- Responsive design
- Modern UI with Tailwind CSS

## Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- Virtual environment (recommended)

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/trackexchange.git
cd trackexchange
```

2. Create and activate a virtual environment:
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up the database:
```bash
python manage.py makemigrations
python manage.py migrate
```

5. Create a superuser:
```bash
python manage.py createsuperuser
```

6. Run the development server:
```bash
python manage.py runserver
```

The application will be available at `http://127.0.0.1:8000/`

## Project Structure

```
trackexchange/
├── core/                 # Main application
│   ├── models.py        # Database models
│   ├── views.py         # View functions
│   └── urls.py          # URL patterns
├── templates/           # HTML templates
│   ├── base.html       # Base template
│   └── core/           # App-specific templates
├── static/             # Static files
│   ├── css/           # CSS files
│   └── js/            # JavaScript files
└── trackexchange/      # Project settings
```

## Usage

1. Register a new account or login with existing credentials
2. Add funds to your wallet
3. Convert between different currencies
4. Send money to bank accounts
5. View transaction history

## Security Features

- PIN-based authentication
- Secure password hashing
- CSRF protection
- Form validation
- Secure session management

## Contributing

1. Fork the repository
2. Create a new branch
3. Make your changes
4. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@trackexchange.com or create an issue in the repository. 