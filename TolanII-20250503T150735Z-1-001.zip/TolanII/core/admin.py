from django.contrib import admin
from .models import ExchangeRate

@admin.register(ExchangeRate)
class ExchangeRateAdmin(admin.ModelAdmin):
    list_display = ('from_currency', 'to_currency', 'rate', 'updated_at')
    list_filter = ('from_currency', 'to_currency')
    search_fields = ('from_currency', 'to_currency')
    readonly_fields = ('updated_at',)

    class Media:
        css = {
            'all': ('core/admin_custom.css',)
        }
