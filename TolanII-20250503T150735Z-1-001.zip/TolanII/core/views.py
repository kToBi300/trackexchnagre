from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.http import JsonResponse
from django.contrib.auth.models import User
from .models import Wallet, Transaction, ExchangeRate, Beneficiary
from decimal import Decimal
from django.db import transaction
from django.views.decorators.http import require_GET

def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'core/home.html')

def signup(request):
    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        password = request.POST.get('password1')
        pin = request.POST.get('pin')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
            return redirect('home')
        
        user = User.objects.create_user(
            username=email,
            email=email,
            password=password,
            first_name=full_name
        )
        
        # Create NGN and USD wallets
        Wallet.objects.create(user=user, currency='NGN', balance=0)
        Wallet.objects.create(user=user, currency='USD', balance=0)
        
        login(request, user)
        return redirect('dashboard')
    
    return redirect('home')

def get_single_user():
    return User.objects.first()

def ensure_wallets(user):
    Wallet.objects.get_or_create(user=user, currency='NGN', defaults={'balance': 0})
    Wallet.objects.get_or_create(user=user, currency='USD', defaults={'balance': 0})

@login_required
def dashboard(request):
    user = request.user
    ensure_wallets(user)
    
    ngn_wallet = Wallet.objects.get(user=user, currency='NGN')
    usd_wallet = Wallet.objects.get(user=user, currency='USD')
    
    # Get the current exchange rate from admin settings
    rate = ExchangeRate.objects.filter(from_currency='NGN', to_currency='USD').first()
    if not rate:
        messages.warning(request, 'Exchange rate not set. Please contact administrator.')
        rate = {'rate': 0}
    
    transactions = Transaction.objects.filter(user=user).order_by('-created_at')[:10]
    
    exchange_rates = ExchangeRate.objects.all()
    context = {
        'ngn_wallet': ngn_wallet,
        'usd_wallet': usd_wallet,
        'rate': rate,
        'transactions': transactions,
        'exchange_rates': exchange_rates,
    }
    return render(request, 'core/dashboard.html', context)

@login_required
def deposit_ngn(request):
    user = request.user
    ensure_wallets(user)
    
    # For testing: Add 1000 NGN to the wallet
    ngn_wallet = Wallet.objects.get(user=user, currency='NGN')
    ngn_wallet.balance += Decimal('1000')
    ngn_wallet.save()
    
    Transaction.objects.create(
        user=user,
        transaction_type='DEPOSIT',
        amount=Decimal('1000'),
        currency='NGN',
        description='Test deposit of 1000 NGN'
    )
    
    messages.success(request, "Added 1000 NGN to your wallet for testing.")
    return redirect('dashboard')

@login_required
def convert_currency(request):
    context = {}
    if request.method == 'POST':
        from_currency = request.POST.get('from_currency')
        to_currency = request.POST.get('to_currency')
        amount = Decimal(request.POST.get('amount', 0))

        if amount <= 0:
            messages.error(request, 'Amount must be greater than 0')
        else:
            rate = ExchangeRate.objects.filter(from_currency=from_currency, to_currency=to_currency).first()
            if not rate:
                messages.error(request, 'Exchange rate not available. Please try again later.')
            else:
                converted_amount = amount * rate.rate
                context = {
                    'converted_amount': converted_amount,
                    'from_currency': from_currency,
                    'to_currency': to_currency,
                    'original_amount': amount,
                    'rate': rate.rate,
                }
    return render(request, 'core/convert.html', context)

@login_required
def send_money(request):
    user = get_single_user()
    ensure_wallets(user)
    if request.method == 'POST':
        currency = request.POST.get('currency')
        amount = Decimal(request.POST.get('amount', 0))
        wallet = Wallet.objects.get(user=user, currency=currency)
        if wallet.balance < amount:
            messages.error(request, "Insufficient funds.")
            return redirect('dashboard')
        wallet.balance -= amount
        wallet.save()
        Transaction.objects.create(
            user=user,
            transaction_type='WITHDRAWAL',
            amount=amount,
            currency=currency,
            description=f'Sent {amount} {currency}'
        )
        messages.success(request, f"Sent {amount} {currency}.")
        return redirect('dashboard')
    return render(request, 'core/send_money.html')

@login_required
def bank_transfer(request):
    if request.method == 'POST':
        amount = Decimal(request.POST.get('amount', 0))
        bank_name = request.POST.get('bank_name')
        account_number = request.POST.get('account_number')
        
        # Create transaction record
        Transaction.objects.create(
            user=request.user,
            transaction_type='TRANSFER',
            amount=amount,
            currency='NGN',
            description=f'Transfer to {bank_name} - {account_number}'
        )
        
        return JsonResponse({'success': True})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def add_beneficiary(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        account_number = request.POST.get('account_number')
        bank_name = request.POST.get('bank_name')
        
        Beneficiary.objects.create(
            user=request.user,
            name=name,
            account_number=account_number,
            bank_name=bank_name
        )
        
        return JsonResponse({'success': True})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def transactions(request):
    user_transactions = Transaction.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'core/transactions.html', {'transactions': user_transactions})

@login_required
def beneficiaries(request):
    user_beneficiaries = Beneficiary.objects.filter(user=request.user)
    return render(request, 'core/beneficiaries.html', {'beneficiaries': user_beneficiaries})

@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "You have been successfully logged out.")
    return redirect('home')

def convert_currency_view(request):
    if request.method == 'POST':
        from_currency = request.POST.get('from_currency')
        to_currency = request.POST.get('to_currency')
        amount = float(request.POST.get('amount'))

        try:
            rate = ExchangeRate.objects.get(from_currency=from_currency, to_currency=to_currency)
            converted_amount = amount * float(rate.rate)
            context = {
                'converted_amount': converted_amount,
                'from_currency': from_currency,
                'to_currency': to_currency,
                'original_amount': amount,
                'rate': rate.rate,
            }
            return render(request, 'core/convert_result.html', context)
        except ExchangeRate.DoesNotExist:
            messages.error(request, 'Exchange rate not set by admin.')
            return redirect('convert')

    return render(request, 'core/convert.html')

def convert_currency(from_currency, to_currency, amount):
    try:
        rate = ExchangeRate.objects.get(from_currency=from_currency, to_currency=to_currency)
        return amount * float(rate.rate)
    except ExchangeRate.DoesNotExist:
        return None

@require_GET
def get_exchange_rate(request):
    from_currency = request.GET.get('from')
    to_currency = request.GET.get('to')
    try:
        rate = ExchangeRate.objects.get(from_currency=from_currency, to_currency=to_currency)
        return JsonResponse({'rate': str(rate.rate)})
    except ExchangeRate.DoesNotExist:
        return JsonResponse({'rate': None})
