from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('transactions/', views.transactions, name='transactions'),
    path('beneficiaries/', views.beneficiaries, name='beneficiaries'),
    path('convert/', views.convert_currency, name='convert_currency'),
    path('transfer/', views.bank_transfer, name='bank_transfer'),
    path('beneficiary/add/', views.add_beneficiary, name='add_beneficiary'),
    path('login/', auth_views.LoginView.as_view(template_name='core/home.html'), name='login'),
    path('signup/', views.signup, name='signup'),
    path('logout/', views.logout_view, name='logout'),
    path('get-exchange-rate/', views.get_exchange_rate, name='get_exchange_rate'),
] 